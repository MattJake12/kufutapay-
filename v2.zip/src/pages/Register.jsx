import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, Store, Smartphone, ArrowRight, 
  ArrowLeft, Lock, CheckCircle2 
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassInput from '../components/ui/GlassInput';
import GlassButton from '../components/ui/GlassButton';

const Register = () => {
  const navigate = useNavigate();
  const { register } = useApp();
  
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  
  // Estado do Formulário
  const [formData, setFormData] = useState({
    name: '',
    businessName: '',
    phone: '',
    smsCode: '',
    pin: '',
    confirmPin: ''
  });

  // Atualizar inputs
  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Navegação entre passos
  const nextStep = () => setStep(prev => prev + 1);
  const prevStep = () => setStep(prev => prev - 1);

  // Ação Final
  const handleFinish = async () => {
    if (formData.pin !== formData.confirmPin) return; // Validação básica
    
    setIsLoading(true);
    await register({
      name: formData.name,
      businessName: formData.businessName,
      phone: formData.phone,
      pin: formData.pin
    });
    // O register do contexto já tem delay, então redirecionamos depois
    navigate('/app/home');
  };

  return (
    <PageTransition className="min-h-full flex flex-col justify-center px-6 relative">
      
      {/* Background Decorativo */}
      <div className="absolute -top-20 -right-20 w-64 h-64 bg-brand-primary/20 rounded-full blur-[80px]" />
      <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-brand-secondary/20 rounded-full blur-[80px]" />

      {/* HEADER DO WIZARD */}
      <div className="mb-8 relative z-10">
        <button 
          onClick={() => step > 1 ? prevStep() : navigate('/')}
          className="flex items-center text-white/50 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft size={18} className="mr-1" /> Voltar
        </button>
        
        <h1 className="text-3xl font-bold text-white mb-2">Criar Conta</h1>
        <p className="text-white/50 text-sm">Passo {step} de 3</p>
        
        {/* Barra de Progresso */}
        <div className="w-full h-1 bg-white/10 mt-4 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${(step / 3) * 100}%` }}
            className="h-full bg-brand-primary"
          />
        </div>
      </div>

      {/* STEPS CONTAINER */}
      <div className="relative z-10 min-h-87.5">
        <AnimatePresence mode="wait">
          
          {/* --- PASSO 1: IDENTIDADE --- */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-4"
            >
              <GlassInput 
                label="Nome Completo"
                icon={User}
                placeholder="Ex: João Silva"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
              />
              <GlassInput 
                label="Nome do Negócio"
                icon={Store}
                placeholder="Ex: Mercearia Central"
                value={formData.businessName}
                onChange={(e) => handleChange('businessName', e.target.value)}
              />
              
              <div className="pt-4">
                <GlassButton 
                  onClick={nextStep} 
                  className="w-full"
                  disabled={!formData.name || !formData.businessName}
                >
                  Continuar <ArrowRight size={18} className="ml-2" />
                </GlassButton>
              </div>
            </motion.div>
          )}

          {/* --- PASSO 2: TELEFONE & SMS --- */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-4"
            >
              <GlassInput 
                label="Número de Telefone"
                icon={Smartphone}
                placeholder="9xx xxx xxx"
                type="tel"
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
              />
              
              <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-xs text-white/60">
                <p>Enviaremos um código SMS para verificar o seu número.</p>
              </div>

              {/* Simulação de Código SMS Input */}
              {formData.phone.length >= 9 && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                  <GlassInput 
                    label="Código SMS (Demo: 1234)"
                    placeholder="• • • •"
                    className="text-center tracking-[1em] font-mono"
                    maxLength={4}
                    value={formData.smsCode}
                    onChange={(e) => handleChange('smsCode', e.target.value)}
                  />
                </motion.div>
              )}
              
              <div className="pt-4">
                <GlassButton 
                  onClick={nextStep} 
                  className="w-full"
                  disabled={formData.smsCode.length < 4}
                >
                  Verificar <CheckCircle2 size={18} className="ml-2" />
                </GlassButton>
              </div>
            </motion.div>
          )}

          {/* --- PASSO 3: SEGURANÇA (PIN) --- */}
          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-4"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-brand-primary/10 rounded-full flex items-center justify-center mx-auto mb-2 text-brand-primary">
                  <Lock size={32} />
                </div>
                <h3 className="font-bold">Defina o seu PIN</h3>
                <p className="text-xs text-white/50">Usado para autorizar vendas e entrar na app</p>
              </div>

              <GlassInput 
                label="PIN de 4 dígitos"
                type="password"
                placeholder="••••"
                maxLength={4}
                className="text-center text-2xl tracking-widest"
                value={formData.pin}
                onChange={(e) => handleChange('pin', e.target.value)}
              />

              <GlassInput 
                label="Confirmar PIN"
                type="password"
                placeholder="••••"
                maxLength={4}
                className="text-center text-2xl tracking-widest"
                value={formData.confirmPin}
                onChange={(e) => handleChange('confirmPin', e.target.value)}
                error={formData.confirmPin && formData.pin !== formData.confirmPin ? "Os PINs não coincidem" : null}
              />
              
              <div className="pt-4">
                <GlassButton 
                  onClick={handleFinish} 
                  variant="primary"
                  className="w-full"
                  isLoading={isLoading}
                  disabled={formData.pin.length < 4 || formData.pin !== formData.confirmPin}
                >
                  Criar Conta
                </GlassButton>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>

    </PageTransition>
  );
};

export default Register;