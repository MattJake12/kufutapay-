import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Delete, Lock, ChevronRight } from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassButton from '../components/ui/GlassButton';

const Login = () => {
  const navigate = useNavigate();
  const { login, user, isLoading } = useApp();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  // Se já estiver logado, redireciona
  useEffect(() => {
    if (user) navigate('/app/home');
  }, [user, navigate]);

  const handleNumberClick = (num) => {
    if (pin.length < 4) {
      setPin(prev => prev + num);
      setError(false);
    }
  };

  const handleDelete = () => {
    setPin(prev => prev.slice(0, -1));
    setError(false);
  };

  const handleLogin = async () => {
    if (pin.length !== 4) return;
    
    // Tenta logar (simulação)
    const success = await login("923000000", pin);
    
    if (success) {
      navigate('/app/home');
    } else {
      setError(true);
      setPin('');
      // Vibração se estiver em mobile
      if (navigator.vibrate) navigator.vibrate(200);
    }
  };

  // Auto-submit quando preenche 4 dígitos
  useEffect(() => {
    if (pin.length === 4) handleLogin();
  }, [pin]);

  return (
    <PageTransition className="min-h-full flex flex-col items-center justify-center p-6 relative">
      
      {/* Background Decorativo */}
      <div className="absolute top-0 left-0 w-full h-1/2 bg-linear-to-b from-brand-primary/10 to-transparent pointer-events-none" />

      <div className="w-full max-w-sm flex flex-col items-center z-10">
        
        {/* Header */}
        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-10 text-center"
        >
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.1)]">
            <Lock size={32} className="text-brand-primary" />
          </div>
          <h1 className="text-2xl font-bold text-white">Bem-vindo de volta</h1>
          <p className="text-white/50 text-sm mt-1">Insira o seu PIN de acesso</p>
        </motion.div>

        {/* PIN Display (Bolinhas) */}
        <motion.div 
          animate={error ? { x: [-10, 10, -10, 10, 0] } : {}}
          className="flex gap-4 mb-12"
        >
          {[0, 1, 2, 3].map((i) => (
            <div 
              key={i}
              className={`
                w-4 h-4 rounded-full transition-all duration-300 border border-white/20
                ${i < pin.length 
                  ? 'bg-brand-primary border-brand-primary shadow-[0_0_10px_rgba(16,185,129,0.5)] scale-110' 
                  : 'bg-transparent'}
              `}
            />
          ))}
        </motion.div>

        {/* Numeric Keypad Customizado */}
        <div className="w-full grid grid-cols-3 gap-x-6 gap-y-6 px-4">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <KeypadButton key={num} onClick={() => handleNumberClick(num)}>
              {num}
            </KeypadButton>
          ))}
          
          <div className="flex items-center justify-center">
            {/* Espaço vazio para alinhar */}
          </div>
          
          <KeypadButton onClick={() => handleNumberClick(0)}>0</KeypadButton>
          
          <button 
            onClick={handleDelete}
            className="flex items-center justify-center w-16 h-16 rounded-full text-white/50 hover:text-white active:bg-white/10 transition-colors"
          >
            <Delete size={28} />
          </button>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center">
          <button 
            onClick={() => alert("Sistema de recuperação de PIN será em breve disponibilizado")}
            className="text-xs text-brand-primary font-medium hover:underline"
          >
            Esqueci o meu PIN
          </button>
          <div className="mt-4 text-[10px] text-white/20">
            Versão Demo 1.0.0 • PayService+
          </div>
        </div>

      </div>

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="w-10 h-10 border-4 border-brand-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}

    </PageTransition>
  );
};

// Componente Local do Botão
const KeypadButton = ({ children, onClick }) => (
  <motion.button
    whileTap={{ scale: 0.85, backgroundColor: "rgba(255,255,255,0.1)" }}
    onClick={onClick}
    className="w-20 h-20 rounded-full text-2xl font-medium text-white bg-white/5 border border-white/5 flex items-center justify-center mx-auto outline-none select-none backdrop-blur-md shadow-lg"
  >
    {children}
  </motion.button>
);

export default Login;