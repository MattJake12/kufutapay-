import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, ArrowRightLeft, ShieldCheck, 
  Smartphone, Wifi, Zap, FileText, Globe 
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassCard from '../components/ui/GlassCard';
import GlassButton from '../components/ui/GlassButton';

const Services = () => {
  const navigate = useNavigate();
  const { user } = useApp();

  // Lista de Serviços Disponíveis (Demo)
  const services = [
    {
      id: 'proof',
      title: 'Validar Transação',
      desc: 'Verificar autenticidade de comprovativos',
      icon: ShieldCheck,
      color: 'text-brand-primary',
      bg: 'bg-brand-primary/10',
      path: '/app/proof-check' // Rota Crítica
    },
    {
      id: 'transfer',
      title: 'Transferências',
      desc: 'Enviar dinheiro para bancos ou carteiras',
      icon: ArrowRightLeft,
      color: 'text-blue-400',
      bg: 'bg-blue-400/10',
      path: '/app/transfer' // ✅ CORRIGIDO
    },
    {
      id: 'recharge',
      title: 'Recargas',
      desc: 'Unitel, Africell e Movicel',
      icon: Smartphone,
      color: 'text-purple-400',
      bg: 'bg-purple-400/10',
      path: null // Sem rota na demo
    },
    {
      id: 'internet',
      title: 'Internet / TV',
      desc: 'Zap, DSTV, NetCasa',
      icon: Wifi,
      color: 'text-pink-400',
      bg: 'bg-pink-400/10',
      path: null
    },
    {
      id: 'utility',
      title: 'Pagamentos',
      desc: 'ENDE (Energia) e EPAL (Água)',
      icon: Zap,
      color: 'text-yellow-400',
      bg: 'bg-yellow-400/10',
      path: null
    },
    {
      id: 'gov',
      title: 'Estado',
      desc: 'Pagamentos de RUPE e Impostos',
      icon: FileText,
      color: 'text-gray-400',
      bg: 'bg-gray-400/10',
      path: null
    }
  ];

  return (
    <PageTransition className="pt-6 px-5 pb-32">
      
      {/* HEADER */}
      <div className="flex items-center gap-3 mb-8">
        <GlassButton variant="ghost" size="icon" onClick={() => navigate('/app/home')} className="rounded-full">
          <ArrowLeft size={20} />
        </GlassButton>
        <div>
          <h1 className="text-xl font-bold">Serviços</h1>
          <p className="text-xs text-white/50">PayService+ Hub</p>
        </div>
      </div>

      {/* FEATURED CARD (O mais importante) */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }} 
        animate={{ y: 0, opacity: 1 }}
        className="mb-8"
      >
        <GlassCard 
          variant="featured" 
          className="flex items-center gap-4 cursor-pointer hover:bg-white/5 transition-colors"
          onClick={() => navigate('/app/proof-check')}
        >
          <div className="w-14 h-14 rounded-full bg-brand-primary text-black flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.4)]">
            <ShieldCheck size={28} strokeWidth={2.5} />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-lg">Anti-Burla</h3>
            <p className="text-sm text-white/60">Validador Oficial</p>
          </div>
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
            <ArrowRightLeft size={16} className="text-white" />
          </div>
        </GlassCard>
      </motion.div>

      {/* GRID DE SERVIÇOS */}
      <h3 className="text-sm font-semibold text-white/50 uppercase tracking-wider mb-4 ml-1">Pagamentos & Utilidades</h3>
      
      <div className="grid grid-cols-2 gap-4">
        {services.slice(1).map((item, index) => (
          <ServiceCard key={item.id} item={item} index={index} navigate={navigate} />
        ))}
      </div>

      {/* BANNER PROMOCIONAL FAKE */}
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 0.5 }}
        className="mt-8 p-4 rounded-2xl bg-linear-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/20 flex items-center gap-3"
      >
        <Globe className="text-blue-400" />
        <div>
          <p className="font-bold text-sm">Transferências Internacionais</p>
          <p className="text-[10px] text-white/50">Em breve na sua carteira PayService+</p>
        </div>
      </motion.div>

    </PageTransition>
  );
};

// Componente Local do Card
const ServiceCard = ({ item, index, navigate }) => {
  const IconComponent = item.icon;
  return (
    <motion.button
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: index * 0.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={() => {
        if (item.path) {
          navigate(item.path);
        } else {
          alert(`${item.title} - Funcionalidade em desenvolvimento`);
        }
      }}
      className="flex flex-col items-start text-left p-4 rounded-3xl bg-glass-100 border border-white/5 hover:bg-white/10 transition-colors h-32 relative overflow-hidden group"
    >
      <div className={`w-10 h-10 rounded-2xl ${item.bg} ${item.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
        <IconComponent size={20} />
      </div>
      
      <div className="relative z-10">
        <h4 className="font-bold text-sm leading-tight mb-1">{item.title}</h4>
        <p className="text-[10px] text-white/40 leading-tight">{item.desc}</p>
      </div>

      {/* Efeito de brilho no hover */}
      <div className="absolute inset-0 bg-linear-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
    </motion.button>
  );
};

export default Services;