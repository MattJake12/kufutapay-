import React from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, Rocket, Target, ShieldCheck, 
  ChevronRight, Lock, Award, Info 
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassCard from '../components/ui/GlassCard';
import GlassButton from '../components/ui/GlassButton';

const Growth = () => {
  const { stats, formatKz, user } = useApp();
  
  // Lógica do Score (Simulada)
  const score = stats.creditScore || 785;
  const scorePercentage = (score / 1000) * 100;
  
  // Categorias de Score
  const getScoreInfo = (s) => {
    if (s > 800) return { label: 'Excelente', color: 'text-emerald-400', bg: 'bg-emerald-400/20' };
    if (s > 600) return { label: 'Bom', color: 'text-brand-primary', bg: 'bg-brand-primary/20' };
    if (s > 400) return { label: 'Regular', color: 'text-yellow-400', bg: 'bg-yellow-400/20' };
    return { label: 'Baixo', color: 'text-red-400', bg: 'bg-red-400/20' };
  };

  const scoreInfo = getScoreInfo(score);
  const savingsProgress = (stats.currentSavings / stats.savingsGoal) * 100;

  return (
    <PageTransition className="pt-6 px-5 pb-32">
      
      {/* HEADER */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">Crescer</h1>
          <p className="text-sm text-white/50">Histórico & Oportunidades</p>
        </div>
        <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-400 border border-purple-500/20">
          <TrendingUp size={24} />
        </div>
      </div>

      <div className="space-y-6">
        
        {/* --- SCORE METER (THE "PERFECTION" PART) --- */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <GlassCard className="relative overflow-hidden flex flex-col items-center py-8">
            {/* Background Glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-brand-primary/10 blur-[60px] rounded-full pointer-events-none" />
            
            <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-6">Seu Score de Confiança</h3>
            
            <div className="relative w-48 h-48 flex items-center justify-center">
              {/* Círculo de Progresso (SVG) */}
              <svg className="w-full h-full -rotate-90">
                <circle 
                  cx="96" cy="96" r="88" 
                  fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="12" 
                />
                <motion.circle 
                  cx="96" cy="96" r="88" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="12" 
                  strokeDasharray="552"
                  strokeDashoffset="552"
                  animate={{ strokeDashoffset: 552 - (552 * scorePercentage) / 100 }}
                  transition={{ duration: 2, ease: "easeOut" }}
                  className={scoreInfo.color}
                  strokeLinecap="round"
                />
              </svg>
              
              <div className="absolute flex flex-col items-center">
                <motion.span 
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  className="text-5xl font-black text-white"
                >
                  {score}
                </motion.span>
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full mt-1 ${scoreInfo.bg} ${scoreInfo.color}`}>
                  {scoreInfo.label}
                </span>
              </div>
            </div>

            <p className="text-[10px] text-white/30 mt-6 text-center px-8">
              O seu score baseia-se na frequência de vendas e regularidade do seu negócio.
            </p>
          </GlassCard>
        </motion.div>

        {/* --- METAS DE POUPANÇA --- */}
        <div>
          <div className="flex justify-between items-end mb-3 px-1">
            <h3 className="text-sm font-bold text-white/80">Meta de Poupança</h3>
            <span className="text-[10px] font-bold text-brand-primary">Destaque do Mês</span>
          </div>
          
          <GlassCard className="p-4 bg-linear-to-br from-white/10 to-transparent">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-brand-primary">
                <Target size={24} />
              </div>
              <div className="flex-1">
                <p className="text-xs text-white/40">Objetivo: Novo Stock</p>
                <h4 className="font-bold">{formatKz(stats.savingsGoal)}</h4>
              </div>
              <div className="text-right">
                <p className="text-xs text-brand-primary font-bold">{Math.round(savingsProgress)}%</p>
              </div>
            </div>
            
            <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden mb-2">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${savingsProgress}%` }}
                transition={{ duration: 1, delay: 0.5 }}
                className="h-full bg-linear-to-r from-brand-primary to-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.5)]"
              />
            </div>
            
            <div className="flex justify-between text-[10px] text-white/30">
              <span>Faltam {formatKz(stats.savingsGoal - stats.currentSavings)}</span>
              <button className="text-brand-primary font-bold hover:underline">Ajustar Meta</button>
            </div>
          </GlassCard>
        </div>

        {/* --- OPORTUNIDADES (PRE-APPROVED) --- */}
        <div>
          <h3 className="text-sm font-bold text-white/80 mb-3 px-1">Oportunidades Disponíveis</h3>
          
          <div className="space-y-3">
            {/* Oferta 1: Micro-crédito (Bloqueado por simulação) */}
            <OpportunityCard 
              icon={Rocket}
              title="Micro-crédito Stock+"
              desc="Até 250.000 Kz aprovados"
              status="Pre-aprovado"
              color="text-brand-primary"
              isLocked={false}
            />

            {/* Oferta 2: Seguro */}
            <OpportunityCard 
              icon={ShieldCheck}
              title="Seguro Saúde Família"
              desc="Proteção para si e funcionários"
              status="Disponível"
              color="text-blue-400"
              isLocked={false}
            />

            {/* Oferta 3: Máquina Nova (Bloqueada) */}
            <OpportunityCard 
              icon={Award}
              title="Upgrade POS Sunmi V2"
              desc="Score 850+ necessário"
              status="Bloqueado"
              color="text-white/20"
              isLocked={true}
            />
          </div>
        </div>

        {/* INFO BANNER */}
        <div className="bg-purple-500/10 border border-purple-500/20 p-4 rounded-2xl flex gap-3">
          <Info className="text-purple-400 shrink-0" size={18} />
          <p className="text-[10px] text-purple-200/70 leading-relaxed">
            A PayService+ não concede crédito diretamente. Utilizamos os seus dados para facilitar o acesso junto de parceiros bancários em Angola.
          </p>
        </div>

      </div>
    </PageTransition>
  );
};

// Componente Local de Card de Oportunidade
const OpportunityCard = ({ icon: Icon, title, desc, status, color, isLocked }) => (
  <GlassCard className={`p-4 flex items-center gap-4 ${isLocked ? 'opacity-60 grayscale' : 'hover:bg-white/5 transition-colors cursor-pointer group'}`}>
    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center bg-white/5 ${color}`}>
      <Icon size={24} />
    </div>
    
    <div className="flex-1">
      <div className="flex items-center gap-1.5">
        <h4 className="font-bold text-sm text-white/90">{title}</h4>
        {isLocked && <Lock size={12} className="text-white/30" />}
      </div>
      <p className="text-[10px] text-white/40">{desc}</p>
    </div>

    <div className="text-right flex flex-col items-end">
      <span className={`text-[9px] font-black uppercase tracking-tighter px-2 py-0.5 rounded ${isLocked ? 'bg-white/10 text-white/30' : 'bg-emerald-500/10 text-brand-primary'}`}>
        {status}
      </span>
      {!isLocked && <ChevronRight size={14} className="text-white/20 mt-1' group-hover:text-white group-hover:translate-x-1 transition-all" />}
    </div>
  </GlassCard>
);

export default Growth;
