import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, ArrowRightLeft, Plus, Minus,
  CheckCircle2, AlertCircle, Copy, Phone, MapPin
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassCard from '../components/ui/GlassCard';
import GlassInput from '../components/ui/GlassInput';
import GlassButton from '../components/ui/GlassButton';

const Transfer = () => {
  const navigate = useNavigate();
  const { wallet, formatKz, processTransfer, isLoading, user } = useApp();
  
  // Estados
  const [step, setStep] = useState('method'); // method | form | confirm | success
  const [transferMethod, setTransferMethod] = useState(null); // 'bank' | 'phone' | 'payservice'
  const [formData, setFormData] = useState({
    recipient: '',
    amount: '',
    description: ''
  });
  const [transferResult, setTransferResult] = useState(null);
  const [error, setError] = useState(null);

  // --- MÉTODOS DE TRANSFERÊNCIA ---
  const methods = [
    {
      id: 'bank',
      title: 'Transferência Bancária',
      desc: 'Para contas no BCI, BAI, etc',
      icon: MapPin,
      color: 'text-blue-400',
      bg: 'bg-blue-500/10'
    },
    {
      id: 'phone',
      title: 'Móbil Money',
      desc: 'Unitel, Africell, Movicel',
      icon: Phone,
      color: 'text-purple-400',
      bg: 'bg-purple-500/10'
    },
    {
      id: 'payservice',
      title: 'PayService+ User',
      desc: 'Outra carteira PayService+',
      icon: ArrowRightLeft,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10'
    }
  ];

  const selectedMethodObj = methods.find(m => m.id === transferMethod);

  // --- HANDLERS ---
  const handleSelectMethod = (methodId) => {
    setTransferMethod(methodId);
    setError(null);
    setStep('form');
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(null);
  };

  const handleReviewTransfer = () => {
    // Validações básicas
    if (!formData.recipient.trim()) {
      setError('Por favor, insira um destinatário');
      return;
    }
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      setError('Insira um valor válido');
      return;
    }
    if (parseFloat(formData.amount) > wallet.balance) {
      setError(`Saldo insuficiente. Tem ${formatKz(wallet.balance)}`);
      return;
    }

    setStep('confirm');
  };

  const handleConfirmTransfer = async () => {
    try {
      const result = await processTransfer({
        type: transferMethod,
        recipient: formData.recipient,
        amount: parseFloat(formData.amount),
        description: formData.description
      });

      setTransferResult(result);
      setStep('success');
    } catch (err) {
      setError(err.message);
    }
  };

  const handleReset = () => {
    setStep('method');
    setTransferMethod(null);
    setFormData({ recipient: '', amount: '', description: '' });
    setError(null);
    setTransferResult(null);
  };

  // --- VALIDAÇÃO DE INPUT POR MÉTODO ---
  const getRecipientPlaceholder = () => {
    switch (transferMethod) {
      case 'bank':
        return 'Ex: 1234567890123456 (IBAN)';
      case 'phone':
        return 'Ex: 923123456 ou 924456789';
      case 'payservice':
        return 'Ex: +244 923 123 456';
      default:
        return 'Destinatário';
    }
  };

  const getRecipientLabel = () => {
    switch (transferMethod) {
      case 'bank':
        return 'Número de Conta';
      case 'phone':
        return 'Número de Telefone';
      case 'payservice':
        return 'Telefone PayService+';
      default:
        return 'Destinatário';
    }
  };

  return (
    <PageTransition className="min-h-full pt-6 px-5 pb-32">
      
      {/* HEADER */}
      <div className="flex items-center gap-3 mb-8">
        <GlassButton 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate('/app/services')} 
          className="rounded-full"
        >
          <ArrowLeft size={20} />
        </GlassButton>
        <div>
          <h1 className="text-xl font-bold">Transferências</h1>
          <p className="text-xs text-white/50">Enviar dinheiro com segurança</p>
        </div>
      </div>

      {/* --- STEP 1: SELECIONAR MÉTODO --- */}
      <AnimatePresence mode="wait">
        {step === 'method' && (
          <motion.div
            key="method"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-4"
          >
            <p className="text-sm text-white/50 mb-6">Como deseja transferir?</p>
            
            <div className="space-y-3">
              {methods.map((method) => (
                <motion.button
                  key={method.id}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleSelectMethod(method.id)}
                  className="w-full"
                >
                  <GlassCard className="flex items-center gap-4 cursor-pointer hover:bg-white/5 transition-all">
                    <div className={`w-12 h-12 rounded-full ${method.bg} flex items-center justify-center`}>
                      <method.icon className={method.color} size={24} />
                    </div>
                    <div className="flex-1 text-left">
                      <h3 className="font-semibold text-white">{method.title}</h3>
                      <p className="text-xs text-white/50">{method.desc}</p>
                    </div>
                    <div className="text-white/30">→</div>
                  </GlassCard>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* --- STEP 2: PREENCHER FORMULÁRIO --- */}
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            {/* Info do Método Selecionado */}
            <GlassCard className="bg-white/5 border-white/10 p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full ${selectedMethodObj?.bg} flex items-center justify-center`}>
                {selectedMethodObj && <selectedMethodObj.icon className={selectedMethodObj.color} size={20} />}
              </div>
              <div className="flex-1">
                <p className="text-xs text-white/50">Transferindo via</p>
                <p className="font-semibold text-white">{selectedMethodObj?.title}</p>
              </div>
              <button
                onClick={() => setStep('method')}
                className="text-white/50 hover:text-white text-xs font-medium"
              >
                Mudar
              </button>
            </GlassCard>

            {/* Formulário */}
            <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleReviewTransfer(); }}>
              {/* Destinatário */}
              <GlassInput
                label={getRecipientLabel()}
                placeholder={getRecipientPlaceholder()}
                value={formData.recipient}
                onChange={(e) => handleInputChange('recipient', e.target.value)}
                className="uppercase"
              />

              {/* Valor */}
              <div>
                <label className="text-xs font-medium text-white/50 uppercase tracking-wider block mb-2">
                  Valor (Kz)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => handleInputChange('amount', e.target.value)}
                    className="w-full bg-glass-200 border border-white/10 rounded-2xl px-4 py-3 text-lg font-bold text-white placeholder-white/20 focus:outline-none focus:border-brand-primary/50 transition-colors"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white/50 text-sm font-medium">
                    Kz
                  </span>
                </div>
              </div>

              {/* Descrição */}
              <GlassInput
                label="Descrição (Opcional)"
                placeholder="Ex: Pagamento de fornecedor"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
              />

              {/* Saldo Disponível */}
              <GlassCard className="bg-white/5 p-3 text-center">
                <p className="text-xs text-white/50 mb-1">Saldo Disponível</p>
                <p className="text-2xl font-bold text-brand-primary">{formatKz(wallet.balance)}</p>
              </GlassCard>

              {/* Erro */}
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 flex gap-3"
                >
                  <AlertCircle size={18} className="text-red-400 shrink-0 mt-0.5" />
                  <p className="text-sm text-red-300">{error}</p>
                </motion.div>
              )}

              {/* Botões */}
              <div className="flex gap-3 pt-4">
                <GlassButton
                  type="button"
                  variant="secondary"
                  onClick={() => setStep('method')}
                >
                  Voltar
                </GlassButton>
                <GlassButton
                  type="submit"
                  className="flex-1 bg-white text-black hover:bg-white/90 border-none font-bold"
                  disabled={!formData.recipient || !formData.amount}
                >
                  Revisar
                </GlassButton>
              </div>
            </form>
          </motion.div>
        )}

        {/* --- STEP 3: CONFIRMAR --- */}
        {step === 'confirm' && (
          <motion.div
            key="confirm"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <GlassCard className="bg-linear-to-b from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 p-6 text-center">
              <AlertCircle size={32} className="text-yellow-400 mx-auto mb-3" />
              <h3 className="font-bold text-yellow-300 mb-2">Revisar Transferência</h3>
              <p className="text-sm text-yellow-200/70">
                Confirme os dados antes de prosseguir. Esta ação não pode ser desfeita.
              </p>
            </GlassCard>

            {/* Resumo */}
            <div className="space-y-3">
              <TransferSummaryRow
                label="Método"
                value={selectedMethodObj?.title}
              />
              <TransferSummaryRow
                label="Destinatário"
                value={formData.recipient}
                mono
              />
              <TransferSummaryRow
                label="Valor"
                value={formatKz(parseFloat(formData.amount))}
                highlight
              />
              {formData.description && (
                <TransferSummaryRow
                  label="Descrição"
                  value={formData.description}
                />
              )}
            </div>

            {/* Botões */}
            <div className="flex gap-3 pt-4">
              <GlassButton
                variant="secondary"
                onClick={() => setStep('form')}
              >
                Editar
              </GlassButton>
              <GlassButton
                onClick={handleConfirmTransfer}
                isLoading={isLoading}
                className="flex-1 bg-white text-black hover:bg-white/90 border-none font-bold"
              >
                Confirmar Transferência
              </GlassButton>
            </div>
          </motion.div>
        )}

        {/* --- STEP 4: SUCESSO --- */}
        {step === 'success' && (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6 text-center py-6"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring' }}
              className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(16,185,129,0.5)]"
            >
              <CheckCircle2 size={32} className="text-black" strokeWidth={3} />
            </motion.div>

            <div>
              <h2 className="text-2xl font-bold text-emerald-400 mb-1">Transferência Realizada!</h2>
              <p className="text-white/50 text-sm">Seu dinheiro foi enviado com sucesso</p>
            </div>

            {/* Detalhes */}
            <GlassCard className="bg-white/5 space-y-3 text-left">
              <TransferSummaryRow label="ID da Transação" value={transferResult?.id} mono small />
              <TransferSummaryRow label="Valor Transferido" value={formatKz(transferResult?.amount)} highlight small />
              <TransferSummaryRow label="Destinatário" value={transferResult?.recipient} small />
              <TransferSummaryRow label="Data" value={new Date(transferResult?.date).toLocaleString('pt-AO')} small />
            </GlassCard>

            {/* Botões */}
            <div className="flex gap-3 pt-4">
              <GlassButton
                variant="secondary"
                className="flex-1"
                onClick={() => navigate('/app/history')}
              >
                Ver no Histórico
              </GlassButton>
              <GlassButton
                onClick={handleReset}
                className="flex-1 bg-white text-black hover:bg-white/90 border-none font-bold"
              >
                Nova Transferência
              </GlassButton>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </PageTransition>
  );
};

// Componentes auxiliares
const TransferSummaryRow = ({ label, value, mono = false, highlight = false, small = false }) => (
  <div className="flex justify-between items-center py-3 px-3 bg-white/5 rounded-lg">
    <span className={`text-xs font-medium text-white/50 uppercase tracking-wider ${small ? '' : 'text-sm'}`}>
      {label}
    </span>
    <span className={`font-semibold ${mono ? 'font-mono' : ''} ${highlight ? 'text-emerald-400 text-lg' : 'text-white'} ${small ? 'text-xs' : 'text-sm'}`}>
      {value}
    </span>
  </div>
);

export default Transfer;
