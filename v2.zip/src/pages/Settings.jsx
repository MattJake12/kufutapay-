import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  User, Store, Lock, Printer, Bell, HelpCircle, 
  LogOut, ChevronRight, CloudCheck, WifiOff 
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassCard from '../components/ui/GlassCard';
import GlassButton from '../components/ui/GlassButton';

const Settings = () => {
  const navigate = useNavigate();
  const { user, logout } = useApp();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <PageTransition className="pt-6 px-5 pb-32">
      
      {/* HEADER */}
      <h1 className="text-2xl font-bold text-white mb-6">Perfil</h1>

      {/* USER CARD */}
      <GlassCard className="flex items-center gap-4 mb-6">
        <div className="w-16 h-16 rounded-full bg-linear-to-br from-brand-primary to-blue-500 p-0.5">
          <img 
            src={user?.avatar || "https://i.pravatar.cc/150"} 
            alt="User" 
            className="w-full h-full rounded-full border-2 border-black object-cover"
          />
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-bold">{user?.name || "Visitante"}</h2>
          <p className="text-sm text-white/50">{user?.businessName || "Sem Negócio"}</p>
          <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded bg-brand-accent/20 text-brand-accent border border-brand-accent/20">
            {user?.tier || "Plano Grátis"}
          </span>
        </div>
        <button className="p-2 bg-white/5 rounded-full hover:bg-white/10">
            <User size={18} className="text-white/70" />
        </button>
      </GlassCard>

      {/* SYSTEM STATUS (CRÍTICO PARA ANGOLA) */}
      <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest ml-1 mb-2">Sistema</h3>
      <GlassCard className="mb-6 p-4">
        <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
                <CloudCheck className="text-emerald-500" size={20} />
                <span className="font-medium text-emerald-400">Sincronizado</span>
            </div>
            <span className="text-xs text-white/40">Há 2 min</span>
        </div>
        <div className="w-full bg-white/10 rounded-full h-1.5 mb-2">
            <div className="bg-emerald-500 h-1.5 rounded-full w-full shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
        </div>
        <div className="flex justify-between text-[10px] text-white/40">
            <span>Transações Offline: 0</span>
            <span>Espaço: 142 MB</span>
        </div>
      </GlassCard>

      {/* MENU GROUPS */}
      <div className="space-y-6">
        
        {/* GRUPO 1: NEGÓCIO */}
        <div>
            <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest ml-1 mb-2">Minha Loja</h3>
            <div className="bg-glass-100 border border-white/5 rounded-2xl overflow-hidden divide-y divide-white/5">
                <MenuItem icon={Store} label="Informações da Loja" onClick={() => alert("Configuração de loja em desenvolvimento")} />
                <MenuItem icon={Printer} label="Impressoras & POS" value="Sunmi V2" onClick={() => alert("Gerenciador de impressoras em desenvolvimento")} />
                <MenuItem icon={Bell} label="Notificações" value="Ativo" onClick={() => alert("Configuração de notificações em desenvolvimento")} />
            </div>
        </div>

        {/* GRUPO 2: SEGURANÇA & SUPORTE */}
        <div>
            <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest ml-1 mb-2">Segurança</h3>
            <div className="bg-glass-100 border border-white/5 rounded-2xl overflow-hidden divide-y divide-white/5">
                <MenuItem icon={Lock} label="Alterar PIN" onClick={() => alert("Alteração de PIN em desenvolvimento")} />
                <MenuItem icon={HelpCircle} label="Ajuda e Tutoriais" onClick={() => alert("Centro de ajuda em desenvolvimento")} />
            </div>
        </div>

        {/* LOGOUT */}
        <button 
            onClick={handleLogout}
            className="w-full py-4 rounded-2xl border border-red-500/20 bg-red-500/5 text-red-400 font-medium flex items-center justify-center gap-2 hover:bg-red-500/10 transition-colors"
        >
            <LogOut size={18} />
            Terminar Sessão
        </button>

        {/* FOOTER VERSION */}
        <div className="text-center py-4 space-y-1">
            <p className="text-xs text-white/30">Versão 2.1.4 (Build 2024)</p>
            <p className="text-[10px] text-white/20">PayService+ © 2026 • Feito para Angola 🇦🇴</p>
        </div>

      </div>

    </PageTransition>
  );
};

// Componente Local de Item de Menu
const MenuItem = ({ icon: Icon, label, value, onClick }) => (
    <button 
        onClick={onClick}
        className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors group"
    >
        <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-white/70 group-hover:text-white group-hover:bg-white/10 transition-colors">
                <Icon size={16} />
            </div>
            <span className="text-sm font-medium text-white/80 group-hover:text-white">{label}</span>
        </div>
        <div className="flex items-center gap-2">
            {value && <span className="text-xs text-white/40">{value}</span>}
            <ChevronRight size={16} className="text-white/20 group-hover:text-white/60" />
        </div>
    </button>
);

export default Settings;