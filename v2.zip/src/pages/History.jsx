import React, { useState, useMemo } from 'react';
import { Search, Filter, Download, CheckCircle2, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassInput from '../components/ui/GlassInput';
import GlassButton from '../components/ui/GlassButton';
import { TransactionItem } from './Home'; // Reutilizando o item visual

const History = () => {
  const { transactions, formatKz } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all'); // 'all', 'in', 'out'
  const [isExporting, setIsExporting] = useState(false);
  const [showToast, setShowToast] = useState(false);

  // --- LÓGICA DE EXPORTAÇÃO (Sincronizada com useEffect para evitar bugs) ---
  const handleDownload = () => {
    if (isExporting) return;
    setIsExporting(true);
    setShowToast(false); // Garante que apaga o anterior
    
    // Simula a geração de um PDF/CSV
    setTimeout(() => {
      setIsExporting(false);
      setShowToast(true);
    }, 2000);
  };

  // --- SEGURANÇA E TIMERS ---
  React.useEffect(() => {
    let timer;
    if (isExporting) {
      // Segurança: se por algum motivo o timeout da função falhar, este garante o reset
      timer = setTimeout(() => setIsExporting(false), 5000);
    }
    return () => clearTimeout(timer);
  }, [isExporting]);

  React.useEffect(() => {
    let timer;
    if (showToast) {
      timer = setTimeout(() => setShowToast(false), 3000);
    }
    return () => clearTimeout(timer);
  }, [showToast]);

  // --- LÓGICA DE FILTRAGEM E AGRUPAMENTO ---
  const filteredAndGroupedTransactions = useMemo(() => {
    // 1. Filtrar
    let filtered = transactions.filter(tx => {
      const matchesSearch = tx.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            tx.method.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = filterType === 'all' 
                          ? true 
                          : filterType === 'in' ? tx.amount > 0 : tx.amount < 0;
      return matchesSearch && matchesType;
    });

    // 2. Agrupar por data
    const grouped = filtered.reduce((acc, tx) => {
      const dateObj = new Date(tx.date);
      const today = new Date();
      const yesterday = new Date();
      yesterday.setDate(today.getDate() - 1);

      let dateKey = dateObj.toLocaleDateString('pt-AO');

      // Títulos amigáveis para datas
      if (dateObj.toDateString() === today.toDateString()) {
        dateKey = 'Hoje';
      } else if (dateObj.toDateString() === yesterday.toDateString()) {
        dateKey = 'Ontem';
      }

      if (!acc[dateKey]) acc[dateKey] = [];
      acc[dateKey].push(tx);
      return acc;
    }, {});

    return grouped;
  }, [transactions, searchTerm, filterType]);

  return (
    <PageTransition className="pt-6 px-5 pb-32">
      
      {/* --- HEADER --- */}
      <div className="flex justify-between items-end mb-6">
        <div>
            <h1 className="text-2xl font-bold text-white mb-1">Carteira</h1>
            <p className="text-sm text-white/50">Todos os seus movimentos</p>
        </div>
        <GlassButton 
          variant="ghost" 
          size="icon" 
          className="bg-white/5 relative overflow-hidden"
          onClick={handleDownload}
          disabled={isExporting}
        >
            <AnimatePresence>
              {isExporting ? (
                <motion.div
                  key="loader"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <Loader2 size={20} className="text-emerald-500 animate-spin" />
                </motion.div>
              ) : (
                <motion.div
                  key="icon"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <Download size={20} />
                </motion.div>
              )}
            </AnimatePresence>
        </GlassButton>
      </div>

      {/* --- TOAST DE SUCESSO --- */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="absolute top-10 left-1/2 -translate-x-1/2 z-[100] flex items-center gap-3 bg-emerald-500 text-black px-4 py-3 rounded-2xl shadow-[0_10px_30px_rgba(16,185,129,0.3)] min-w-[280px]"
          >
            <div className="bg-white/20 p-1.5 rounded-full">
              <CheckCircle2 size={18} />
            </div>
            <div>
              <p className="text-sm font-bold">Relatório Gerado!</p>
              <p className="text-[10px] opacity-80 uppercase tracking-wider font-medium">Extrato_Mensal_Jan.pdf</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- CONTROLS (SEARCH & FILTER) --- */}
      <div className="space-y-4 mb-6 sticky top-0 z-20 bg-brand-dark/80 backdrop-blur-xl py-2 -mx-2 px-2 rounded-b-2xl transition-all">
        <GlassInput 
            icon={Search}
            placeholder="Buscar por nome, ref ou método..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-black/40"
        />

        <div className="flex gap-2">
            <FilterButton 
                label="Todas" 
                isActive={filterType === 'all'} 
                onClick={() => setFilterType('all')} 
            />
            <FilterButton 
                label="Entradas" 
                isActive={filterType === 'in'} 
                onClick={() => setFilterType('in')} 
                color="bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
            />
            <FilterButton 
                label="Saídas" 
                isActive={filterType === 'out'} 
                onClick={() => setFilterType('out')} 
                color="bg-red-500/20 text-red-400 border-red-500/30"
            />
        </div>
      </div>

      {/* --- LISTA AGRUPADA --- */}
      <div className="space-y-6">
        {Object.keys(filteredAndGroupedTransactions).length === 0 ? (
            <div className="text-center py-20 opacity-50">
                <Filter size={48} className="mx-auto mb-4 text-white/20" />
                <p>Nenhuma transação encontrada.</p>
            </div>
        ) : (
            Object.entries(filteredAndGroupedTransactions).map(([dateLabel, txs]) => (
                <motion.div 
                    key={dateLabel}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-3"
                >
                    <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest pl-1 sticky top-36">
                        {dateLabel}
                    </h3>
                    
                    <AnimatePresence>
                        {txs.map((tx) => (
                            <TransactionItem key={tx.id} tx={tx} formatKz={formatKz} />
                        ))}
                    </AnimatePresence>
                </motion.div>
            ))
        )}
      </div>

    </PageTransition>
  );
};

const FilterButton = ({ label, isActive, onClick, color }) => (
    <button
        onClick={onClick}
        className={`
            px-4 py-1.5 rounded-full text-xs font-medium border transition-all duration-300
            ${isActive 
                ? (color || 'bg-white text-black border-white shadow-lg shadow-white/10') 
                : 'bg-white/5 text-white/50 border-transparent hover:bg-white/10'}
        `}
    >
        {label}
    </button>
);

export default History;