import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Smartphone, BarChart3, ShieldCheck } from 'lucide-react';

import PageTransition from '../components/ui/PageTransition';
import GlassButton from '../components/ui/GlassButton';

// Dados dos Slides (Copywriting exato do cliente)
const ONBOARDING_STEPS = [
  {
    id: 1,
    title: "Receba pagamentos com facilidade",
    description: "Aceite pagamentos por telefone, cartão ou dinheiro móvel. Tudo num só lugar.",
    icon: Smartphone,
    color: "bg-blue-500",
    illustration: (
      <div className="relative w-full h-full flex items-center justify-center">
        <div className="absolute w-40 h-40 bg-blue-500/30 rounded-full blur-2xl animate-pulse" />
        <div className="relative z-10 bg-glass-200 border border-white/10 p-4 rounded-3xl -rotate-6 shadow-2xl">
          <div className="w-32 h-48 bg-black/40 rounded-2xl flex flex-col items-center justify-center gap-2">
            <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white">
              <Smartphone size={24} />
            </div>
            <div className="h-2 w-16 bg-white/20 rounded-full" />
            <div className="h-2 w-10 bg-white/10 rounded-full" />
          </div>
        </div>
      </div>
    )
  },
  {
    id: 2,
    title: "Acompanhe suas vendas em tempo real",
    description: "Veja quanto vendeu hoje, esta semana e este mês. Dados claros e simples.",
    icon: BarChart3,
    color: "bg-emerald-500",
    illustration: (
      <div className="relative w-full h-full flex items-center justify-center">
        <div className="absolute w-40 h-40 bg-emerald-500/30 rounded-full blur-2xl animate-pulse" />
        <div className="relative z-10 w-48 h-32 bg-glass-200 border border-white/10 p-4 rounded-xl shadow-2xl flex items-end gap-2">
          <motion.div initial={{ height: 0 }} animate={{ height: '40%' }} className="w-full bg-emerald-500/30 rounded-t-md" />
          <motion.div initial={{ height: 0 }} animate={{ height: '70%' }} className="w-full bg-emerald-500/60 rounded-t-md" />
          <motion.div initial={{ height: 0 }} animate={{ height: '100%' }} className="w-full bg-emerald-500 rounded-t-md" />
        </div>
      </div>
    )
  },
  {
    id: 3,
    title: "Seguro e funciona offline",
    description: "Seus dados estão protegidos. Funciona mesmo sem internet e sincroniza depois.",
    icon: ShieldCheck,
    color: "bg-purple-500",
    illustration: (
      <div className="relative w-full h-full flex items-center justify-center">
        <div className="absolute w-40 h-40 bg-purple-500/30 rounded-full blur-2xl animate-pulse" />
        <ShieldCheck size={120} className="text-purple-400 drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]" />
      </div>
    )
  }
];

const Welcome = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);

  const step = ONBOARDING_STEPS[currentStep];

  const handleNext = () => {
    if (currentStep < ONBOARDING_STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      navigate('/register');
    }
  };

  return (
    <PageTransition className="min-h-full flex flex-col relative bg-brand-dark">
      
      {/* Background Shapes */}
      <div className="absolute top-0 left-0 w-full h-1/2 bg-linear-to-b from-brand-primary/5 to-transparent pointer-events-none" />

      {/* --- ÁREA DA ILUSTRAÇÃO (METADE SUPERIOR) --- */}
      <div className="flex-1 relative flex items-center justify-center pt-10 px-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={step.id}
            initial={{ opacity: 0, scale: 0.8, x: 50 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.8, x: -50 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="w-full h-full max-h-75 flex items-center justify-center"
          >
            {step.illustration}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* --- ÁREA DE TEXTO (METADE INFERIOR) --- */}
      <div className="bg-glass-100 backdrop-blur-2xl border-t border-white/10 rounded-t-[40px] p-8 pb-12 flex flex-col justify-between min-h-[45%] shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
        
        <div>
          {/* Indicadores (Dots) */}
          <div className="flex gap-2 mb-6 justify-center">
            {ONBOARDING_STEPS.map((s, idx) => (
              <motion.div 
                key={s.id}
                animate={{ 
                  width: idx === currentStep ? 24 : 8,
                  backgroundColor: idx === currentStep ? '#10B981' : 'rgba(255,255,255,0.2)'
                }}
                className="h-2 rounded-full transition-all duration-300"
              />
            ))}
          </div>

          {/* Texto Animado */}
          <AnimatePresence mode="wait">
            <motion.div
              key={step.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-center space-y-3"
            >
              <h2 className="text-2xl font-bold text-white leading-tight">
                {step.title}
              </h2>
              <p className="text-white/60 text-sm leading-relaxed px-4">
                {step.description}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Botões de Ação */}
        <div className="space-y-4 mt-8">
          <GlassButton 
            onClick={handleNext} 
            variant="primary" 
            className="w-full font-bold text-lg shadow-brand-primary/20"
          >
            {currentStep === ONBOARDING_STEPS.length - 1 ? 'Começar' : 'Continuar'}
            {currentStep < ONBOARDING_STEPS.length - 1 && <ArrowRight size={20} className="ml-2" />}
          </GlassButton>

          <button 
            onClick={() => navigate('/login')}
            className={`w-full text-center text-sm font-medium transition-colors ${
              currentStep === ONBOARDING_STEPS.length - 1 ? 'text-white/80' : 'text-white/40 hover:text-white'
            }`}
          >
            {currentStep === ONBOARDING_STEPS.length - 1 ? 'Prefere entrar? Login' : 'Já tem conta? Entrar'}
          </button>
        </div>

      </div>

    </PageTransition>
  );
};

export default Welcome;