import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Delete, CreditCard, Banknote, QrCode, 
  CheckCircle2, X, Share2, Printer, ChevronRight 
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassButton from '../components/ui/GlassButton';
import GlassCard from '../components/ui/GlassCard';

const POS = () => {
  const navigate = useNavigate();
  const { processSale, formatKz, isLoading } = useApp();
  
  const [amountStr, setAmountStr] = useState('0');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentStep, setPaymentStep] = useState('input'); // input | method | processing | success
  const [selectedMethod, setSelectedMethod] = useState(null);
  const [successData, setSuccessData] = useState(null);

  // --- LÓGICA DA CALCULADORA ---
  const handleNumber = (num) => {
    if (amountStr.length > 9) return; // Limite
    if (amountStr === '0' && num !== '00') {
      setAmountStr(num.toString());
    } else if (amountStr !== '0') {
      setAmountStr(prev => prev + num);
    }
  };

  const handleDelete = () => {
    if (amountStr.length === 1) {
      setAmountStr('0');
    } else {
      setAmountStr(prev => prev.slice(0, -1));
    }
  };

  const handleClear = () => setAmountStr('0');

  // --- LÓGICA DE PAGAMENTO ---
  const initiatePayment = () => {
    if (parseFloat(amountStr) === 0) return;
    setPaymentStep('method');
    setShowPaymentModal(true);
  };

  const confirmPayment = async (method) => {
    setSelectedMethod(method);
    setPaymentStep('processing');
    
    // Processa a venda no contexto
    const tx = await processSale(parseFloat(amountStr), method);
    
    setSuccessData(tx);
    setPaymentStep('success');
  };

  const resetPOS = () => {
    setAmountStr('0');
    setShowPaymentModal(false);
    setPaymentStep('input');
    setSuccessData(null);
  };

  const amount = parseFloat(amountStr);

  return (
    <PageTransition className="min-h-full flex flex-col relative">
      
      {/* --- DISPLAY (VISOR) --- */}
      <div className="flex-1 flex flex-col justify-center items-end px-8 pb-8 pt-12">
        <p className="text-white/50 text-sm font-medium uppercase tracking-wider mb-2">Valor a Cobrar</p>
        <motion.div 
            key={amountStr}
            initial={{ scale: 0.9, opacity: 0.5 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-6xl font-bold text-white tracking-tight"
        >
            {new Intl.NumberFormat('pt-AO').format(amount)}
            <span className="text-2xl text-brand-primary ml-2 font-normal">Kz</span>
        </motion.div>
      </div>

      {/* --- KEYPAD (TECLADO) --- */}
      <div className="bg-glass-200 backdrop-blur-2xl rounded-t-[40px] border-t border-white/10 p-6 pb-28 shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
        <div className="grid grid-cols-3 gap-4 mb-6">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <PosButton key={num} onClick={() => handleNumber(num)}>{num}</PosButton>
            ))}
            <PosButton onClick={() => handleNumber('00')} className="text-xl">00</PosButton>
            <PosButton onClick={() => handleNumber(0)}>0</PosButton>
            <PosButton onClick={handleDelete} variant="secondary">
                <Delete size={24} />
            </PosButton>
        </div>

        <div className="flex gap-3">
            <GlassButton 
                variant="ghost" 
                className="w-20 bg-white/5 border border-white/5 text-white/50"
                onClick={handleClear}
            >
                C
            </GlassButton>
            <GlassButton 
                variant="primary" 
                className="flex-1 text-lg font-bold shadow-brand-primary/20"
                disabled={amount === 0}
                onClick={initiatePayment}
            >
                COBRAR
            </GlassButton>
        </div>
      </div>

      {/* --- MODAL DE PAGAMENTO (BOTTOM SHEET) --- */}
      <AnimatePresence>
        {showPaymentModal && (
            <>
                {/* Backdrop Escuro */}
                <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => paymentStep !== 'processing' && setShowPaymentModal(false)}
                    className="absolute inset-0 bg-black/80 backdrop-blur-sm z-40"
                />

                {/* O Modal em Si */}
                <motion.div 
                    initial={{ y: "100%" }}
                    animate={{ y: 0 }}
                    exit={{ y: "100%" }}
                    transition={{ type: "spring", damping: 25, stiffness: 300 }}
                    className="absolute bottom-0 left-0 right-0 bg-[#0f172a] rounded-t-[35px] border-t border-white/10 z-50 p-6 pb-12 shadow-2xl min-h-[50%]"
                >
                    {/* Header do Modal */}
                    <div className="w-12 h-1.5 bg-white/10 rounded-full mx-auto mb-8" />

                    {/* FASE 1: ESCOLHER MÉTODO */}
                    {paymentStep === 'method' && (
                        <div className="space-y-4">
                            <h2 className="text-xl font-bold text-center mb-6">Escolha o método</h2>
                            <div className="grid gap-3">
                                <PaymentOption 
                                    icon={Banknote} 
                                    title="Dinheiro Físico" 
                                    desc="Registo imediato de caixa"
                                    onClick={() => confirmPayment('Dinheiro')}
                                    color="text-emerald-400"
                                />
                                <PaymentOption 
                                    icon={QrCode} 
                                    title="Multicaixa / QR" 
                                    desc="Gerar código para o cliente"
                                    onClick={() => confirmPayment('Multicaixa QR')}
                                    color="text-brand-secondary"
                                />
                                <PaymentOption 
                                    icon={CreditCard} 
                                    title="Referência" 
                                    desc="Pagamento por entidade"
                                    onClick={() => confirmPayment('Referência')}
                                    color="text-purple-400"
                                />
                            </div>
                        </div>
                    )}

                    {/* FASE 2: PROCESSAMENTO (QR CODE FAKE) */}
                    {paymentStep === 'processing' && (
                        <div className="flex flex-col items-center justify-center py-10 space-y-6">
                             {selectedMethod === 'Multicaixa QR' ? (
                                <div className="bg-white p-4 rounded-xl shadow-lg animate-pulse">
                                    <QrCode size={150} className="text-black" />
                                </div>
                             ) : (
                                <div className="w-20 h-20 border-4 border-brand-primary border-t-transparent rounded-full animate-spin" />
                             )}
                             
                             <p className="text-white/60 animate-pulse">
                                {selectedMethod === 'Multicaixa QR' ? 'A aguardar scan do cliente...' : 'Processando transação...'}
                             </p>
                        </div>
                    )}

                    {/* FASE 3: SUCESSO / RECIBO */}
                    {paymentStep === 'success' && successData && (
                        <div className="flex flex-col items-center text-center">
                            <motion.div 
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center text-black mb-4 shadow-[0_0_40px_rgba(16,185,129,0.4)]"
                            >
                                <CheckCircle2 size={40} strokeWidth={3} />
                            </motion.div>
                            
                            <h2 className="text-2xl font-bold text-white mb-1">Pagamento Recebido!</h2>
                            <p className="text-brand-primary text-xl font-mono font-bold mb-8">
                                {formatKz(successData.amount)}
                            </p>

                            <GlassCard className="w-full mb-6 bg-white/5 border-dashed border-white/20">
                                <div className="flex justify-between text-sm mb-2">
                                    <span className="text-white/40">ID Transação</span>
                                    <span className="font-mono">{successData.id}</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span className="text-white/40">Método</span>
                                    <span>{successData.method}</span>
                                </div>
                            </GlassCard>

                            <div className="flex gap-3 w-full">
                                <GlassButton 
                                  onClick={() => navigate('/app/receipt', { state: { transaction: successData } })} 
                                  variant="secondary" 
                                  className="flex-1"
                                >
                                    <Printer size={18} className="mr-2" /> Recibo
                                </GlassButton>
                                <GlassButton onClick={resetPOS} variant="primary" className="flex-1">
                                    Nova Venda
                                </GlassButton>
                            </div>
                        </div>
                    )}

                </motion.div>
            </>
        )}
      </AnimatePresence>

    </PageTransition>
  );
};

// --- COMPONENTES AUXILIARES LOCAIS ---

const PosButton = ({ children, onClick, variant = 'default', className }) => (
    <motion.button
        whileTap={{ scale: 0.95, backgroundColor: "rgba(255,255,255,0.15)" }}
        onClick={onClick}
        className={`
            h-16 rounded-2xl text-2xl font-medium transition-all duration-200 outline-none select-none
            ${variant === 'default' ? 'bg-white/5 text-white border border-white/5 hover:bg-white/10' : ''}
            ${variant === 'secondary' ? 'bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 flex items-center justify-center' : ''}
            ${className}
        `}
    >
        {children}
    </motion.button>
);

const PaymentOption = ({ icon: Icon, title, desc, onClick, color }) => (
    <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={onClick}
        className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors text-left"
    >
        <div className={`w-12 h-12 rounded-full bg-opacity-10 flex items-center justify-center ${color}`} style={{ backgroundColor: `${color.match(/\d+/)?.[0] || 'rgb(59, 130, 246)'}/10` }}>
            <Icon size={24} />
        </div>
        <div>
            <h3 className="font-bold text-white">{title}</h3>
            <p className="text-xs text-white/50">{desc}</p>
        </div>
        <ChevronRight size={20} className="ml-auto text-white/20" />
    </motion.button>
);

export default POS;