import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, Share2, Printer, CheckCircle2, 
  MapPin, Clock, Hash, ChevronRight 
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassButton from '../components/ui/GlassButton';

const Receipt = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { formatKz } = useApp();

  // Recebe dados via navegação. Se não tiver, usa mock para evitar erro na demo.
  const tx = location.state?.transaction || {
    id: "DEMO-1234",
    amount: 5000,
    date: new Date().toISOString(),
    title: "Venda Demo",
    method: "Dinheiro",
    status: "completed",
    reference: "---"
  };

  return (
    <PageTransition className="min-h-full flex flex-col pt-6 px-5 pb-8 bg-[#020617]">
      
      {/* HEADER NAVBAR */}
      <div className="flex justify-between items-center mb-6">
        <GlassButton variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full">
          <ArrowLeft size={20} />
        </GlassButton>
        <span className="text-sm font-medium opacity-50">Detalhe da Transação</span>
        <div className="w-10" /> {/* Espaçador para centralizar */}
      </div>

      {/* O RECIBO (PAPER LOOK) */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="flex-1 max-w-sm mx-auto w-full relative group"
      >
        {/* Borda superior do papel */}
        <div className="h-4 bg-white rounded-t-2xl relative z-10" />

        {/* Corpo do Recibo - Fundo Branco para Contraste Máximo */}
        <div className="bg-white text-slate-900 p-6 relative">
          
          {/* Logo / Brand */}
          <div className="flex justify-center mb-6 opacity-40 grayscale">
            {/* Simplesmente o texto ou logo svg */}
            <h2 className="font-bold tracking-widest text-xs border-2 border-slate-900 px-2 py-1 uppercase">PayService+</h2>
          </div>

          {/* Status Icon */}
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
              <CheckCircle2 size={32} />
            </div>
          </div>

          {/* Valor Principal */}
          <div className="text-center mb-8 border-b-2 border-dashed border-slate-200 pb-8">
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Valor Total</p>
            <h1 className="text-4xl font-bold text-slate-900">{formatKz(tx.amount)}</h1>
            <div className="inline-block mt-2 px-3 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full uppercase">
              Sucesso
            </div>
          </div>

          {/* Grid de Detalhes */}
          <div className="space-y-4 text-sm">
            <ReceiptRow icon={Hash} label="Referência" value={tx.id} mono />
            <ReceiptRow icon={Clock} label="Data & Hora" value={new Date(tx.date).toLocaleString()} />
            <ReceiptRow icon={MapPin} label="Método" value={tx.method} />
            <ReceiptRow icon={CheckCircle2} label="Status" value={tx.status === 'completed' ? 'Aprovado' : 'Pendente'} />
          </div>

          {/* Rodapé do Recibo */}
          <div className="mt-12 pt-6 border-t border-slate-200 text-center">
            <p className="text-[10px] text-slate-400">
              Obrigado pela preferência.<br/>
              Este documento serve como comprovativo de venda.
            </p>
            {/* Código de Barras Fake */}
            <div className="h-8 mt-4 bg-[url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVR4AWP4z8DwHwwDGUwwBQA42A4A/y/T4QAAAABJRU5ErkJggg==')] bg-repeat-x opacity-30" />
          </div>

        </div>

        {/* Borda inferior "Zig Zag" (CSS Clip Path) */}
        <div 
          className="h-4 bg-white w-full relative z-10"
          style={{ 
            clipPath: 'polygon(0% 0%, 5% 100%, 10% 0%, 15% 100%, 20% 0%, 25% 100%, 30% 0%, 35% 100%, 40% 0%, 45% 100%, 50% 0%, 55% 100%, 60% 0%, 65% 100%, 70% 0%, 75% 100%, 80% 0%, 85% 100%, 90% 0%, 95% 100%, 100% 0%)' 
          }}
        />

      </motion.div>

      {/* AÇÕES FIXAS */}
      <div className="mt-8 grid grid-cols-2 gap-4 max-w-sm mx-auto w-full">
        <GlassButton 
          variant="secondary" 
          className="bg-white/5"
          onClick={() => {
            if (navigator.print) navigator.print();
          }}
        >
          <Printer size={18} className="mr-2" /> Imprimir
        </GlassButton>
        <GlassButton 
          variant="primary"
          onClick={() => {
            if (navigator.share) {
              navigator.share({
                title: 'Comprovativo',
                text: `Comprovativo da venda de ${tx.method}`,
              }).catch(() => {});
            }
          }}
        >
          <Share2 size={18} className="mr-2" /> Partilhar
        </GlassButton>
      </div>

    </PageTransition>
  );
};

const ReceiptRow = ({ icon: Icon, label, value, mono }) => (
  <div className="flex justify-between items-center">
    <div className="flex items-center gap-2 text-slate-400">
      <Icon size={14} />
      <span className="text-xs font-medium">{label}</span>
    </div>
    <span className={`font-bold text-slate-800 ${mono ? 'font-mono' : ''}`}>
      {value}
    </span>
  </div>
);

export default Receipt;