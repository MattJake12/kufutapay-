import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Eye, EyeOff, Plus, ArrowUpRight, 
  ScanLine, QrCode, TrendingUp, Bell 
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassCard from '../components/ui/GlassCard';
import GlassButton from '../components/ui/GlassButton';

const Home = () => {
  const navigate = useNavigate();
  const { user, wallet, stats, transactions, formatKz } = useApp();
  const [showBalance, setShowBalance] = useState(true);

  // Variantes de animação para os itens aparecerem em cascata
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <PageTransition className="pt-6 px-5 pb-32"> {/* Padding bottom extra para o menu flutuante */}
      
      {/* --- HEADER --- */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
          <motion.div 
            initial={{ scale: 0 }} animate={{ scale: 1 }}
            className="w-10 h-10 rounded-full bg-linear-to-tr from-brand-secondary to-purple-500 p-0.5"
          >
            <img 
              src={user?.avatar || "https://i.pravatar.cc/150"} 
              alt="Profile" 
              className="w-full h-full rounded-full border-2 border-black object-cover"
            />
          </motion.div>
          <div>
            <p className="text-xs text-white/60">Boa tarde,</p>
            <h1 className="text-lg font-bold leading-tight">{user?.name?.split(' ')[0] || 'Comerciante'}</h1>
          </div>
        </div>
        
        <GlassButton 
          variant="ghost" 
          size="icon" 
          className="rounded-full bg-white/5 border-none"
          onClick={() => navigate('/app/notifications')}
        >
          <Bell size={20} className="text-white" />
          <span className="absolute top-3 right-3 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
        </GlassButton>
      </div>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="space-y-6"
      >

        {/* --- BALANCE CARD (HERO) --- */}
        <motion.div variants={itemVariants}>
          <GlassCard variant="featured" className="relative overflow-hidden py-6">
            {/* Background Effects */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-primary/20 blur-[50px] rounded-full -translate-y-1/2 translate-x-1/2" />
            
            <div className="relative z-10">
              <div className="flex justify-between items-start mb-2">
                <span className="text-sm font-medium text-white/70 flex items-center gap-2">
                  Saldo Disponível
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                </span>
                <button 
                  onClick={() => setShowBalance(!showBalance)}
                  className="text-white/50 hover:text-white transition-colors p-1"
                >
                  {showBalance ? <Eye size={18} /> : <EyeOff size={18} />}
                </button>
              </div>

              <div className="mb-6">
                <h2 className="text-4xl font-bold tracking-tight text-transparent bg-clip-text bg-linear-to-r from-white via-white to-white/70">
                  {showBalance ? formatKz(wallet.balance) : '•••••••'}
                </h2>
                {wallet.pendingBalance > 0 && showBalance && (
                  <p className="text-xs text-brand-accent mt-1 font-medium">
                    + {formatKz(wallet.pendingBalance)} a confirmar
                  </p>
                )}
              </div>

              <div className="flex gap-3">
                <GlassButton 
                  onClick={() => navigate('/app/pos')} 
                  className="flex-1 bg-white text-black hover:bg-white/90 shadow-lg shadow-white/10 font-bold border-none"
                >
                  <Plus size={18} className="mr-1" /> Vender
                </GlassButton>
                <GlassButton 
                  onClick={() => navigate('/app/transfer')} 
                  variant="secondary" 
                  className="flex-1"
                >
                  <ArrowUpRight size={18} className="mr-1" /> Transferir
                </GlassButton>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* --- QUICK ACTIONS GRID --- */}
        <motion.div variants={itemVariants}>
          <h3 className="text-sm font-semibold text-white/50 mb-3 ml-1 uppercase tracking-wider">Acesso Rápido</h3>
          <div className="grid grid-cols-4 gap-3">
            <ActionButton 
              icon={ScanLine} 
              label="Validar" 
              color="text-brand-accent"
              onClick={() => navigate('/app/proof-check')} 
            />
            <ActionButton 
              icon={QrCode} 
              label="QR Code" 
              color="text-blue-400"
              onClick={() => navigate('/app/pos')} // Atalho
            />
            <ActionButton 
              icon={TrendingUp} 
              label="Metas" 
              color="text-purple-400"
              onClick={() => navigate('/app/growth')}
            />
            <ActionButton 
              icon={Plus} 
              label="Serviços" 
              color="text-brand-primary"
              onClick={() => navigate('/app/services')}
            />
          </div>
        </motion.div>

        {/* --- INSIGHTS / STATS --- */}
        <motion.div variants={itemVariants}>
          <GlassCard className="flex items-center justify-between p-4">
            <div>
              <p className="text-xs text-white/50 mb-1">Vendas de Hoje</p>
              <div className="flex items-end gap-2">
                <span className="text-xl font-bold">{formatKz(stats.todaySales)}</span>
                <span className="text-xs text-brand-primary font-medium mb-1 bg-brand-primary/10 px-1.5 py-0.5 rounded">
                  +{stats.weekGrowth}%
                </span>
              </div>
            </div>
            
            {/* Mini Sparkline Chart SVG */}
            <div className="w-24 h-12">
              <svg viewBox="0 0 100 50" className="w-full h-full overflow-visible">
                <path 
                  d="M0 40 Q 20 45, 40 30 T 100 10" 
                  fill="none" 
                  stroke="#10B981" 
                  strokeWidth="3" 
                  strokeLinecap="round"
                />
                <circle cx="100" cy="10" r="3" fill="#10B981" />
                <linearGradient id="fillGradient" x1="0" x2="0" y1="0" y2="1">
                   <stop offset="0%" stopColor="#10B981" stopOpacity="0.2" />
                   <stop offset="100%" stopColor="#10B981" stopOpacity="0" />
                </linearGradient>
                <path 
                   d="M0 40 Q 20 45, 40 30 T 100 10 V 50 H 0 Z" 
                   fill="url(#fillGradient)" 
                   stroke="none"
                />
              </svg>
            </div>
          </GlassCard>
        </motion.div>

        {/* --- RECENT TRANSACTIONS PREVIEW --- */}
        <motion.div variants={itemVariants}>
          <div className="flex justify-between items-center mb-3 px-1">
            <h3 className="text-sm font-semibold text-white/50 uppercase tracking-wider">Últimos Movimentos</h3>
            <button 
              onClick={() => navigate('/app/history')}
              className="text-xs text-brand-primary font-medium hover:underline"
            >
              Ver todos
            </button>
          </div>
          
          <div className="space-y-3">
            {transactions.slice(0, 3).map((tx) => (
              <TransactionItem key={tx.id} tx={tx} formatKz={formatKz} />
            ))}
          </div>
        </motion.div>

      </motion.div>
    </PageTransition>
  );
};

// --- SUB-COMPONENTES PARA LIMPEZA DO CÓDIGO ---

const ActionButton = ({ icon: Icon, label, color, onClick }) => (
  <button 
    onClick={onClick}
    className="flex flex-col items-center gap-2 group"
  >
    <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/5 group-active:scale-95 transition-all flex items-center justify-center hover:bg-white/10 hover:border-white/10 shadow-lg">
      <Icon size={24} className={color} />
    </div>
    <span className="text-[11px] font-medium text-white/60 group-hover:text-white transition-colors">
      {label}
    </span>
  </button>
);

// Este componente será reutilizado no History.jsx, mas defini aqui para o Home funcionar isolado
export const TransactionItem = ({ tx, formatKz }) => {
  const isPositive = tx.amount > 0;
  const isPending = tx.status === 'pending';

  return (
    <GlassCard className="p-3 flex items-center justify-between group active:scale-[0.99] transition-transform">
      <div className="flex items-center gap-3">
        <div className={`
          w-10 h-10 rounded-full flex items-center justify-center border border-white/5
          ${isPositive ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}
        `}>
          {isPositive 
            ? <ArrowUpRight size={18} /> 
            : <ArrowUpRight size={18} className="rotate-180" /> 
          }
        </div>
        <div>
          <p className="text-sm font-semibold text-white/90">{tx.title}</p>
          <p className="text-xs text-white/40 flex items-center gap-1">
            {new Date(tx.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} • {tx.method}
          </p>
        </div>
      </div>
      
      <div className="text-right">
        <p className={`text-sm font-bold ${isPositive ? 'text-white' : 'text-white/80'}`}>
          {isPositive ? '+' : ''}{formatKz(tx.amount)}
        </p>
        {isPending && (
          <span className="text-[10px] font-bold text-brand-accent bg-brand-accent/10 px-1.5 py-0.5 rounded">
            Pendente
          </span>
        )}
      </div>
    </GlassCard>
  );
};

export default Home;