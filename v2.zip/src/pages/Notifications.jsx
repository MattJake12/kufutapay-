import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Bell, BellOff, CheckCircle2, Info } from 'lucide-react';

import PageTransition from '../components/ui/PageTransition';
import GlassButton from '../components/ui/GlassButton';
import GlassCard from '../components/ui/GlassCard';

const Notifications = () => {
    const navigate = useNavigate();

    const notifications = [
        {
            id: 1,
            title: "Pagamento Recebido",
            desc: "Recebeu 5.200 Kz via QR Code (Multicaixa).",
            time: "10 min atrás",
            type: "success",
            icon: CheckCircle2,
            color: "text-emerald-500",
            bg: "bg-emerald-500/10"
        },
        {
            id: 2,
            title: "Simulação de Crédito",
            desc: "O seu histórico de 30 dias foi validado. Veja a sua oferta de crédito.",
            time: "2 horas atrás",
            type: "info",
            icon: Info,
            color: "text-blue-400",
            bg: "bg-blue-400/10"
        },
        {
            id: 3,
            title: "Atualização do Sistema",
            desc: "Versão 1.2.0 instalada com sucesso. Novas funções de relatórios.",
            time: "1 dia atrás",
            type: "system",
            icon: Bell,
            color: "text-purple-400",
            bg: "bg-purple-400/10"
        }
    ];

    return (
        <PageTransition className="pt-6 px-5 pb-32">
            
            {/* HEADER */}
            <div className="flex items-center gap-3 mb-8">
                <GlassButton variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full">
                    <ArrowLeft size={20} />
                </GlassButton>
                <div>
                    <h1 className="text-xl font-bold">Notificações</h1>
                    <p className="text-xs text-white/50">Centro de Alertas</p>
                </div>
            </div>

            {notifications.length > 0 ? (
                <div className="space-y-4">
                    {notifications.map((notif, index) => (
                        <motion.div
                            key={notif.id}
                            initial={{ x: 20, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <GlassCard className="flex items-start gap-4 p-4">
                                <div className={`w-10 h-10 rounded-full shrink-0 flex items-center justify-center ${notif.bg} ${notif.color}`}>
                                    <notif.icon size={20} />
                                </div>
                                <div className="flex-1">
                                    <div className="flex justify-between items-start mb-1">
                                        <h3 className="font-bold text-sm text-white/90">{notif.title}</h3>
                                        <span className="text-[10px] text-white/30 whitespace-nowrap">{notif.time}</span>
                                    </div>
                                    <p className="text-xs text-white/50 leading-relaxed">{notif.desc}</p>
                                </div>
                            </GlassCard>
                        </motion.div>
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-20 opacity-30 text-center">
                    <BellOff size={64} className="mb-4" />
                    <p className="font-medium">Nenhuma notificação por agora</p>
                </div>
            )}

        </PageTransition>
    );
};

export default Notifications;
