import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ShieldCheck, Search, ScanLine, ArrowLeft, 
  CheckCircle2, XCircle, Copy, Share2 
} from 'lucide-react';

import { useApp } from '../context/AppContext';
import PageTransition from '../components/ui/PageTransition';
import GlassCard from '../components/ui/GlassCard';
import GlassInput from '../components/ui/GlassInput';
import GlassButton from '../components/ui/GlassButton';

const ProofCheck = () => {
  const navigate = useNavigate();
  const { verifyProof, formatKz, isLoading } = useApp();
  
  const [code, setCode] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [showScanner, setShowScanner] = useState(false); // Simulação de UI

  const handleVerify = async (e) => {
    e?.preventDefault();
    if (!code) return;

    setResult(null);
    setError(null);

    try {
      const data = await verifyProof(code);
      setResult(data);
    } catch (err) {
      setError("Código inválido ou não encontrado no sistema PayService+.");
    }
  };

  return (
    <PageTransition className="min-h-full flex flex-col px-5 pt-6 pb-24 relative">
      
      {/* HEADER */}
      <div className="flex items-center gap-3 mb-8">
        <GlassButton variant="ghost" size="icon" onClick={() => navigate(-1)} className="w-10 h-10 rounded-full">
          <ArrowLeft size={20} />
        </GlassButton>
        <h1 className="text-xl font-bold">Validar Transação</h1>
      </div>

      {/* HERO SECTION */}
      <div className="text-center mb-8">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-20 h-20 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-500/20 shadow-[0_0_30px_rgba(59,130,246,0.2)]"
        >
          <ShieldCheck size={40} className="text-blue-400" />
        </motion.div>
        <h2 className="text-lg font-semibold text-white">Verificador Oficial</h2>
        <p className="text-sm text-white/50 px-4">
          Insira o código da transação para confirmar a autenticidade do pagamento.
        </p>
      </div>

      {/* FORMULÁRIO */}
      <form onSubmit={handleVerify} className="space-y-4 relative z-10">
        <GlassInput 
          icon={Search}
          placeholder="Ex: PS-2024-X ou REF-123"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="text-center font-mono tracking-wider uppercase"
        />

        <div className="flex gap-3">
          <GlassButton 
            type="button" 
            variant="secondary" 
            className="px-4"
            onClick={() => setShowScanner(!showScanner)}
          >
            <ScanLine size={20} />
          </GlassButton>
          <GlassButton 
            type="submit" 
            variant="primary" 
            className="flex-1"
            isLoading={isLoading}
            disabled={!code}
          >
            Verificar Agora
          </GlassButton>
        </div>
      </form>

      {/* SIMULAÇÃO DE SCANNER (Aparece se clicar no botão de scan) */}
      <AnimatePresence>
        {showScanner && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 200, opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mt-6 bg-black/50 rounded-2xl overflow-hidden relative border border-white/10"
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-xs text-white/50">Câmera Simulada</p>
            </div>
            <div className="absolute inset-0 border-2 border-brand-primary/50 m-8 rounded-lg animate-pulse" />
            <div className="absolute top-1/2 left-8 right-8 h-0.5 bg-red-500 shadow-[0_0_10px_red] animate-[slideUp_2s_infinite_alternate]" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* RESULTADOS (MODAL INLINE) */}
      <AnimatePresence mode="wait">
        
        {/* SUCESSO */}
        {result && (
          <motion.div
            key="success"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="mt-8"
          >
            <div className="bg-linear-to-b from-emerald-500/20 to-emerald-900/10 border border-emerald-500/30 rounded-3xl p-1 relative overflow-hidden">
              {/* Confetti effect fake */}
              <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20" />
              
              <div className="bg-black/40 backdrop-blur-xl rounded-[20px] p-6 text-center">
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center text-black shadow-[0_0_20px_rgba(16,185,129,0.5)]">
                    <CheckCircle2 size={24} strokeWidth={3} />
                  </div>
                </div>
                
                <h3 className="text-emerald-400 font-bold text-lg mb-1">Transação Autêntica</h3>
                <p className="text-xs text-white/40 mb-6">Verificado em {new Date().toLocaleTimeString()}</p>

                <div className="space-y-3 mb-6 text-left">
                  <DetailRow label="Valor" value={formatKz(result.amount)} highlight />
                  <DetailRow label="Entidade" value={result.entity} />
                  <DetailRow label="Data" value={result.date} />
                  <DetailRow label="Tipo" value={result.type} />
                </div>

                <GlassButton 
                  onClick={() => {
                    navigate('/app/receipt', { state: { transaction: result } });
                  }}
                  className="w-full h-10 text-sm bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30"
                >
                  Ver Recibo Completo
                </GlassButton>
              </div>
            </div>
          </motion.div>
        )}

        {/* ERRO */}
        {error && (
          <motion.div
            key="error"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-8 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-3"
          >
            <XCircle className="text-red-500 shrink-0" size={20} />
            <div>
              <h4 className="font-bold text-red-400 text-sm">Não Encontrado</h4>
              <p className="text-xs text-red-200/60 mt-1 leading-relaxed">{error}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* DICA DE RODAPÉ */}
      <div className="absolute bottom-24 left-0 right-0 text-center px-6">
        <p className="text-[10px] text-white/20">
          A validação confirma apenas que a transação existe no sistema PayService+. Sempre verifique a sua conta bancária.
        </p>
      </div>

    </PageTransition>
  );
};

const DetailRow = ({ label, value, highlight }) => (
  <div className="flex justify-between items-center py-2 border-b border-white/5 last:border-0">
    <span className="text-xs text-white/50">{label}</span>
    <span className={`text-sm font-medium ${highlight ? 'text-white text-lg font-bold' : 'text-white/80'}`}>
      {value}
    </span>
  </div>
);

export default ProofCheck;