import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import DeviceFrame from './DeviceFrame';
import BottomDock from '../ui/BottomDock'; // Descomentado!

const AppLayout = () => {
  const location = useLocation();
  
  // O menu (dock) só aparece nas rotas internas da aplicação (que começam com /app)
  const showDock = location.pathname.startsWith('/app');

  return (
    <DeviceFrame>
      <main className="w-full h-full relative">
        <Outlet />
        
        {showDock && (
          <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center px-4">
            <BottomDock />
          </div>
        )}
      </main>
    </DeviceFrame>
  );
};

export default AppLayout;