import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Wifi, Battery, Signal } from 'lucide-react';

const DeviceFrame = ({ children }) => {
  const scrollRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startY, setStartY] = useState(0);
  const [scrollTop, setScrollTop] = useState(0);

  const handleMouseDown = (e) => {
    // Só ativa o arraste se não for um dispositivo touch nativo (que já tem o scroll tátil)
    if (window.matchMedia('(pointer: coarse)').matches) return;
    
    setIsDragging(true);
    setStartY(e.pageY - (scrollRef.current?.offsetTop || 0));
    setScrollTop(scrollRef.current?.scrollTop || 0);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e) => {
    if (!isDragging || !scrollRef.current) return;
    
    const y = e.pageY - (scrollRef.current?.offsetTop || 0);
    const walk = (y - startY) * 1.5; 
    
    // Só previne o comportamento padrão e move se o movimento for significativo
    if (Math.abs(y - startY) > 5) {
      e.preventDefault();
      scrollRef.current.scrollTop = scrollTop - walk;
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#050505] flex items-center justify-center relative overflow-hidden">
      
      {/* --- BACKGROUND DESKTOP (ESTÚDIO PROFISSIONAL) --- */}
      <div className="absolute inset-0 z-0 hidden md:block">
        {/* Padrão de Grelha Técnica */}
        <div className="absolute inset-0 bg-grid-pattern opacity-50" />
        
        {/* Luz de Estúdio Central (Spotlight) */}
        <div className="absolute inset-0 studio-spotlight" />
        
        {/* Vinheta (Escurecer cantos) */}
        <div className="absolute inset-0 bg-linear-to-t from-[#020617] via-transparent to-[#020617]" />
        <div className="absolute inset-0 bg-linear-to-r from-[#020617] via-transparent to-[#020617]" />
      </div>

      {/* --- TEXTO DE APRESENTAÇÃO (Aparece ao lado no Desktop) --- */}
      <div className="hidden xl:flex flex-col absolute left-20 top-1/2 -translate-y-1/2 z-10 max-w-xs">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center text-black font-bold text-xl shadow-[0_0_20px_rgba(16,185,129,0.3)]">
            P+
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">PayService+</h1>
            <span className="text-xs font-mono text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">
              MVP BUILD v1.0
            </span>
          </div>
        </div>
        <div className="space-y-4 border-l border-white/10 pl-6">
          <div>
            <h3 className="text-white font-medium">Investidor Demo</h3>
            <p className="text-sm text-white/40 mt-1">
              Ambiente de teste para validação de fluxos financeiros e usabilidade.
            </p>
          </div>
          <div>
            <h3 className="text-white font-medium">Modo de Exibição</h3>
            <p className="text-sm text-white/40 mt-1">
              iPhone 15 Pro Max • iOS 17 View
            </p>
          </div>
        </div>
      </div>

      {/* --- O DEVICE FRAME (iPhone 15 Pro Max - TITANIUM) --- */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "circOut" }}
        className="relative z-20 w-full h-full md:w-[410px] md:h-[860px] md:max-h-[92vh] flex flex-col"
      >
        {/* Borda Externa (Titanium Frame) */}
        <div className="hidden md:block absolute -inset-[3px] bg-linear-to-b from-[#4b4b4b] via-[#2a2a2a] to-[#1a1a1a] rounded-[60px] shadow-2xl" />
        
        {/* Borda Interna (Bezel Preto) */}
        <div className="relative w-full h-full bg-black md:rounded-[56px] overflow-hidden flex flex-col md:border-[8px] md:border-black shadow-[0_0_50px_rgba(0,0,0,0.5)]">
          
          {/* Botões Laterais (Só Desktop) */}
          <div className="hidden md:block absolute top-24 -left-3 w-1 h-8 bg-[#333] rounded-l-md" /> {/* Mute */}
          <div className="hidden md:block absolute top-36 -left-3 w-1 h-16 bg-[#333] rounded-l-md" /> {/* Vol Up */}
          <div className="hidden md:block absolute top-56 -left-3 w-1 h-16 bg-[#333] rounded-l-md" /> {/* Vol Down */}
          <div className="hidden md:block absolute top-40 -right-3 w-1 h-24 bg-[#333] rounded-r-md" /> {/* Power */}

          {/* Dynamic Island / Status Bar */}
          <div className="z-50 px-6 pt-3 pb-2 flex justify-between items-center bg-transparent absolute top-0 left-0 right-0 text-white pointer-events-none hidden md:flex">
            <span className="text-[13px] font-semibold w-12 text-center ml-2">9:41</span>
            
            {/* Dynamic Island (Só Desktop) */}
            <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 top-3 w-[120px] h-[35px] bg-black rounded-[20px] justify-center items-center z-50">
               <div className="w-2 h-2 rounded-full bg-[#1a1a1a] ml-16 opacity-60"></div> {/* Câmera fake */}
            </div>

            <div className="flex gap-2 items-center w-12 mr-2">
              <Signal size={14} fill="currentColor" />
              <Wifi size={14} />
              <Battery size={16} fill="currentColor" />
            </div>
          </div>

          {/* CONTEÚDO DA APP */}
          <div 
            ref={scrollRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseLeave}
            tabIndex="0"
            className={`flex-1 w-full h-full overflow-y-auto overflow-x-hidden no-scrollbar bg-[#020617] relative scroll-smooth outline-none transition-colors ${isDragging ? 'cursor-grabbing select-none' : 'cursor-grab'}`}
          >
             {/* Reflexo de Vidro (Glass Glare) - Subtil */}
             <div className="absolute top-0 right-0 w-full h-100 bg-linear-to-bl from-white/5 to-transparent pointer-events-none z-60 hidden md:block" />
             
             <div className="min-h-full pb-32 md:pt-12 pt-14 pointer-events-auto">
               {children}
             </div>
          </div>

          {/* Home Indicator (Barra inferior iOS) */}
          <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-36 h-1.5 bg-white/20 rounded-full z-50 hidden md:block" />
        
        </div>
      </motion.div>

    </div>
  );
};

export default DeviceFrame;