import React, { useState } from 'react';
import { cn } from '../../utils/cn';

const GlassInput = ({ 
  label, 
  icon: Icon, 
  rightElement,
  className, 
  error,
  type = "text",
  ...props 
}) => {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <div className={cn("w-full space-y-1.5", className)}>
      {label && (
        <label className="text-xs font-medium text-white/60 ml-1">
          {label}
        </label>
      )}
      
      <div className={cn(
        "relative flex items-center w-full rounded-2xl transition-all duration-300 border bg-black/20 backdrop-blur-md",
        isFocused ? "border-brand-primary/50 shadow-[0_0_15px_rgba(16,185,129,0.15)] bg-black/30" : "border-white/10 hover:border-white/20",
        error ? "border-red-500/50" : ""
      )}>
        
        {/* Ícone à Esquerda */}
        {Icon && (
          <div className="pl-4 text-white/40">
            <Icon size={18} />
          </div>
        )}

        <input
          type={type}
          className="w-full bg-transparent border-none px-4 py-3.5 text-white placeholder:text-white/20 focus:ring-0 text-base font-medium outline-none"
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          {...props}
        />

        {/* Elemento à Direita (ex: Botão 'Ver' password ou Texto 'Kz') */}
        {rightElement && (
          <div className="pr-4">
            {rightElement}
          </div>
        )}
      </div>

      {error && (
        <p className="text-xs text-red-400 ml-1 animate-fade-in">
          {error}
        </p>
      )}
    </div>
  );
};

export default GlassInput;