import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Home, Wallet, ScanLine, TrendingUp, Menu, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

const DockItem = ({ to, icon: Icon, label, isActive, isCenter = false }) => {
  return (
    <NavLink to={to} className="relative group">
      <div className={cn(
        "flex flex-col items-center justify-center transition-all duration-300",
        isCenter ? "-mt-6" : ""
      )}>
        
        {/* Container do Ícone */}
        <motion.div
          whileTap={{ scale: 0.9 }}
          animate={isActive && !isCenter ? { y: -5 } : { y: 0 }}
          className={cn(
            "rounded-2xl flex items-center justify-center transition-all duration-300",
            isCenter 
              ? "w-16 h-16 bg-linear-to-tr from-brand-primary to-emerald-400 text-black shadow-[0_0_20px_rgba(16,185,129,0.4)] border-4 border-brand-dark" 
              : "w-10 h-10 hover:bg-white/10",
            isActive && !isCenter ? "text-brand-primary bg-white/5" : "text-white/50"
          )}
        >
          <Icon size={isCenter ? 28 : 22} strokeWidth={isCenter ? 2.5 : 2} />
        </motion.div>

        {/* Label (Ponto ou Texto) */}
        {!isCenter && (
          <span className={cn(
            "text-[10px] font-medium mt-1 transition-colors duration-300",
            isActive ? "text-white" : "text-transparent group-hover:text-white/30"
          )}>
            {isActive ? '•' : label}
          </span>
        )}
      </div>
    </NavLink>
  );
};

const BottomDock = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  return (
    <div className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-[35px] px-6 py-3 shadow-2xl flex items-center justify-between gap-2 max-w-85 w-full">
      
      <DockItem 
        to="/app/home" 
        icon={Home} 
        label="Início" 
        isActive={currentPath === '/app/home'} 
      />
      
      <DockItem 
        to="/app/history" 
        icon={Wallet} 
        label="Carteira" 
        isActive={currentPath === '/app/history'} 
      />

      {/* Botão Central de Ação (POS) */}
      <DockItem 
        to="/app/pos" 
        icon={Zap} 
        label="Vender" 
        isActive={currentPath === '/app/pos'} 
        isCenter 
      />

      <DockItem 
        to="/app/growth" 
        icon={TrendingUp} 
        label="Crescer" 
        isActive={currentPath === '/app/growth'} 
      />

      <DockItem 
        to="/app/settings" 
        icon={Menu} 
        label="Menu" 
        isActive={currentPath === '/app/settings'} 
      />

    </div>
  );
};

export default BottomDock;