import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

const GlassCard = ({ 
  children, 
  className, 
  variant = 'default', // default | featured | dark
  onClick,
  ...props 
}) => {
  
  const variants = {
    default: "bg-glass-100 border-white/5",
    featured: "bg-gradient-to-br from-white/10 to-white/5 border-white/10 shadow-lg shadow-black/20",
    dark: "bg-black/40 border-white/5",
  };

  return (
    <motion.div
      whileTap={onClick ? { scale: 0.98 } : {}}
      className={cn(
        "relative overflow-hidden rounded-3xl backdrop-blur-xl border p-5",
        "transition-all duration-300",
        variants[variant],
        className
      )}
      onClick={onClick}
      {...props}
    >
      {/* Efeito de brilho/ruído subtil no fundo */}
      <div className="absolute inset-0 bg-white/5 opacity-0 hover:opacity-10 transition-opacity duration-500 pointer-events-none" />
      
      {/* Conteúdo */}
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
};

export default GlassCard;