/**
 * MOCK DATA - PAYSERVICE+ VISION
 * Dados simulados para o contexto de Angola.
 * As datas são geradas dinamicamente para parecerem sempre recentes.
 */

const getRelativeDate = (daysOffset, hours = 12, minutes = 0) => {
    const date = new Date();
    date.setDate(date.getDate() - daysOffset);
    date.setHours(hours, minutes, 0, 0);
    return date.toISOString();
  };
  
  export const INITIAL_DATA = {
    user: {
      name: "João Silva",
      businessName: "Mercearia do Povo",
      phone: "923 456 789",
      pin: "1234", // PIN de demonstração
      avatar: "https://i.pravatar.cc/150?u=joao",
      isVerified: true,
      tier: "Gold", // Nível do comerciante
    },
    
    wallet: {
      balance: 142500, // Saldo inicial em Kz
      pendingBalance: 12000, // Saldo a cair (QR Code)
      lastSync: new Date().toISOString(),
    },
  
    stats: {
      todaySales: 25400,
      todayCount: 8,
      weekGrowth: 12, // %
      topSellingTime: "16:00 - 18:00",
      savingsGoal: 500000,
      currentSavings: 150000,
      creditScore: 785, // Score de 0 a 1000
    },
  
    // Lista inicial de transações
    transactions: [
      {
        id: "TX-9981",
        type: "sale_cash", // Venda em Dinheiro
        title: "Venda Presencial",
        amount: 3500,
        date: getRelativeDate(0, 14, 32), // Hoje
        status: "completed",
        method: "Dinheiro",
        reference: "---"
      },
      {
        id: "TX-9980",
        type: "sale_qr", // Venda QR Code
        title: "Pagamento QR",
        amount: 5200,
        date: getRelativeDate(0, 13, 15), // Hoje
        status: "pending", // Aparece amarelo
        method: "Multicaixa",
        reference: "MC-88219"
      },
      {
        id: "TX-9979",
        type: "sale_qr",
        title: "Pagamento QR",
        amount: 2100,
        date: getRelativeDate(0, 12, 48), // Hoje
        status: "completed",
        method: "Kikuia",
        reference: "KK-11209"
      },
      {
        id: "TX-9978",
        type: "expense", // Pagamento de Serviço
        title: "Fornecedor Coca-Cola",
        amount: -12000,
        date: getRelativeDate(0, 10, 0), // Hoje
        status: "completed",
        method: "Transferência",
        reference: "REF-9910"
      },
      // Ontem
      {
        id: "TX-9977",
        type: "service", // Recarga
        title: "Recarga Unitel",
        amount: 1000,
        date: getRelativeDate(1, 18, 45),
        status: "completed",
        method: "Saldo",
        reference: "UTL-5543"
      },
      {
        id: "TX-9976",
        type: "sale_cash",
        title: "Venda Presencial",
        amount: 7800,
        date: getRelativeDate(1, 16, 20),
        status: "completed",
        method: "Dinheiro",
        reference: "---"
      },
      {
        id: "TX-9975",
        type: "sale_ref", // Pagamento por Referência
        title: "Pagamento Referência",
        amount: 15000,
        date: getRelativeDate(1, 9, 30),
        status: "completed",
        method: "BAI Directo",
        reference: "882 192 001"
      },
      // Semana Passada
      {
        id: "TX-9970",
        type: "withdrawal", // Levantamento
        title: "Levantamento",
        amount: -50000,
        date: getRelativeDate(3, 11, 0),
        status: "completed",
        method: "Agente Bancário",
        reference: "LEV-3321"
      }
    ]
  };
  
  // Códigos válidos para a funcionalidade "Consultar Comprovativo"
  export const VALID_PROOF_CODES = [
    { code: "PS-2024-X", amount: 5000, date: "2024-05-10 14:30", entity: "Maria Cliente", type: "Transferência Recebida" },
    { code: "123456", amount: 12500, date: "Hoje 10:00", entity: "Fornecedor Zé", type: "Pagamento Fornecedor" }
  ];